/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author naido
 */
public class Q3 {
    public static double greatestCommonDivisor(int p, int q){
        double ans = 0;
        
        int g = 0;
        if(p < 0 || q < 0){
            return ans;
        }
        else {
            while (p % q > 0){
                g = p % q;
                p = q;
                q = g;
            }
            return q;
        }
    
    }
}
