/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author naido
 */
public class Q2 {
    public static void main(String[] args){
    /*
    int max = 12;
    int sum = oddSquaresSum(max);
    System.out.println("Sum of squares of odd numbers up to " + max + ": " + sum);
    }
    */
    
    int max = 20;
    long sum = oddSquaresSum(max);
    System.out.println("Sum of odds for limit = " + max + " is " + sum);
    int p = 30, q = 15;
    double GCD = Q3.greatestCommonDivisor(p, q);
    System.out.println("Greatest common divisor is = " + GCD);
    }
    
    
    public static int oddSquaresSum(int max){
        int sum = 0;
        for (int n = 1; n <= max; n+=2){
            sum += n * n;
        }
        return sum;
    }
    
    
}
