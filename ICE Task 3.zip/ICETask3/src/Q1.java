/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author naido
 */
public class Q1 {
    public static boolean isValid(String validity){
        if (validity == null || validity.length() == 0)
            return false;
        
        StringBuilder firstParentheses =  new StringBuilder();
        
        for (char b : validity.toCharArray()){
            if (b == '(' || b == '{' || b == '['){
                firstParentheses.append(b);
            } else 
                if (b == ')' || b == '}' || b == ']'){
                    if (firstParentheses.length() == 0)
                        return false;
                
            char lastParentheses = firstParentheses.charAt(firstParentheses.length() - 1);
            
            if ((b == ')' && lastParentheses != '(') ||
                (b == '}' && lastParentheses != '{') ||
                (b == ']' && lastParentheses != '[')) {
                return false;
            }
            firstParentheses.deleteCharAt(firstParentheses.length() - 1);
            } 
         } 
        return firstParentheses.length() == 0;
    }
    public static void main(String[] args){
        String[] testcases = {"{}{)}", "", "{[}]", "()", "({[]})"};
        for (String test : testcases){
            System.out.println(test + " - " + (isValid(test) ? "valid" : "invalid"));
        }
    }
}
