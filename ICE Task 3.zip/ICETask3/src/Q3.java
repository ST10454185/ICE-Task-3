/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Scanner;
/**
 *
 * @author naido
 */
public class Q3 {
    public static void main(String[] args){
        
    
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter a first number: ");
        int a = input.nextInt();
        System.out.println("Enter a second number: ");
        int b = input.nextInt();
    
        int g = 0;
        for(int i = 1; i <= a; i++){
            if(a % i == 0 && b % i == 0)
                g = i;
        }
        System.out.println("GCD = " + g);
    }
}
